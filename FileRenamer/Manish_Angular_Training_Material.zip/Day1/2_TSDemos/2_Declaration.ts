// Implicitly Typed

// var data = 10;
// data = "ABC";

// var data1 = "AbC";

// var data;
// data = 10;
// data = "ABC";

// Explicitly Typed
// var age: number;
// age = 10;

function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
// console.log(add(2, "Hello"));

// var x;
