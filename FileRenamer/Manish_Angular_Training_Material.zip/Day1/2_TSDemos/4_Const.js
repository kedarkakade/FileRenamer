var env = "dev";
if (true) {
    var env_1 = "prod";
}
