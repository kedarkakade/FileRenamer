class Program {
    public static main(arg: string): void {
        console.log("Hello", arg);
    }

    public static check(){}
}

Program.main("World");
// Program.main(10);