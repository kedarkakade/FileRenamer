var Program = /** @class */ (function () {
    function Program() {
    }
    Program.main = function (arg) {
        console.log("Hello", arg);
    };
    Program.check = function () { };
    return Program;
}());
Program.main("World");
// Program.main(10);
