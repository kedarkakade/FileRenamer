// function Person(age: number) {
//     this.age = age;
//     this.growOld = () =>{
//         this.age += 1;
//     }
// }

// var p = new Person(20);
// setInterval(p.growOld, 1000);

// setInterval(function () {
//     console.log(p.age);
// }, 1000);