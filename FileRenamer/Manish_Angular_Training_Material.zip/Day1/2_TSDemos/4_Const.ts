const env = "dev";

if (true) {
    const env = "prod";
}

