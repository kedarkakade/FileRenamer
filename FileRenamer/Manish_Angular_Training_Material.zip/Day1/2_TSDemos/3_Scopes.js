// var a1 = 10;
// (function () {
//     var a1 = 1000;
//     console.log(a1);
// })();
// console.log(a1);
// var i = 10;
// console.log("Before, i is ", i);;
// // (function(){
// //     for (var i = 0; i < 5; i++) {
// //         console.log("Inside, i is ", i);;
// //     }
// // })();
// for (var i = 0; i < 5; i++) {
//     console.log("Inside, i is ", i);;
// }
// console.log("After, i is ", i);;
// --------------------------------------------- Typescript
// let a1 = 10;
// let a1 = 1000;
var i = 10;
console.log("Before, i is ", i);
for (var i_1 = 0; i_1 < 5; i_1++) {
    console.log("Inside, i is ", i_1);
}
console.log("After, i is ", i);
