class Logger {
    log(msg) {
        console.log(msg + ", logged using Logger..");
    }
}

module.exports = Logger;