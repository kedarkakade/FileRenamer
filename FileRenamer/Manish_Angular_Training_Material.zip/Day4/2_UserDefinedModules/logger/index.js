module.exports.log = function(msg){
    console.log(msg + " logged using index.js from Folder");
}