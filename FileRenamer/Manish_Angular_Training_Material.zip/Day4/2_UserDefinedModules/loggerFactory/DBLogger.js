class DBLogger {
    log(msg) {
        console.log(msg + ", logged in Database..");
    }
}

module.exports = DBLogger;