class FileLogger {
    log(msg) {
        console.log(msg + ", logged in File..");
    }
}

module.exports = FileLogger;