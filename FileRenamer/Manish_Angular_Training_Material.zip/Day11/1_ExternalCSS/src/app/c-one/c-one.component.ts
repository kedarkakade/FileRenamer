import { Component } from "@angular/core";

@Component({
    selector: 'c-one',
    styleUrls: ['./c-one.component.css'],
    templateUrl: './c-one.component.html'
})
export class COneComponent { }