function GetLength(arg) {
    return arg.length;
}
console.log(GetLength("Manish"));
console.log(GetLength(["Manish"]));
console.log(GetLength([10, 0, 30, 40]));
