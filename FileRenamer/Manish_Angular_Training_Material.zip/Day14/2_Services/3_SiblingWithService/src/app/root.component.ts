import { Component, OnInit } from '@angular/core';
import { AuthorsService } from './services/authors.service';

@Component({
    selector: 'root',
    templateUrl: 'root.component.html',
    providers: [AuthorsService]
})

export class RootComponent implements OnInit {
    constructor() { }

    ngOnInit() {
    }
}