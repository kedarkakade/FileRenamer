import { Component, OnInit } from '@angular/core';
import { AuthorsService } from './services/authors.service';
import { Observable, Observer, Subject } from 'rxjs';

@Component({
    selector: 'root',
    templateUrl: 'root.component.html',
    providers: [AuthorsService]
})

export class RootComponent implements OnInit {
    observable: Observable<any>;
    subject: Subject<any>;

    constructor() { }

    ngOnInit() {
        // this.observable = Observable.create((ob: Observer<any>) => {
        //     setInterval(() => {
        //         ob.next(Math.random());
        //     }, 2000);
        // });

        // this.observable.subscribe((number) => {
        //     console.log("S1 - ", number);
        // });

        // this.observable.subscribe((number) => {
        //     console.log("S2 - ", number);
        // });

        // this.subject = new Subject<any>();

        // this.subject.subscribe((number) => {
        //     console.log("S1 - ", number);
        // });

        // this.subject.subscribe((number) => {
        //     console.log("S2 - ", number);
        // });

        // setInterval(() => {
        //     this.subject.next(Math.random());
        // }, 2000);
    }
}