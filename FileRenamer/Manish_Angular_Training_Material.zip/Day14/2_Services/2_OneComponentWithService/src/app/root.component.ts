import { Component, OnInit, Inject } from '@angular/core';
import { Author } from './models/app.author';
import { AuthorsService } from './services/authors.service';

@Component({
    selector: 'root',
    templateUrl: 'root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [AuthorsService]
})

export class RootComponent implements OnInit {
    list: Array<Author>;
    selectedAuthor: Author;

    // constructor(@Inject(AuthorsService) private _aService: any) { }
    constructor(private _aService: AuthorsService) { }


    ngOnInit() {
        this.list = this._aService.Authors;
    }

    selectAuthor(a: Author) {
        this.selectedAuthor = a;
    }

    isSelected(a: Author) {
        return this.selectedAuthor === a;
    }
}