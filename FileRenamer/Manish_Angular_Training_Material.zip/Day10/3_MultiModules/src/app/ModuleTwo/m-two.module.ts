import { NgModule } from "@angular/core";
import { CTwoComponent } from "./c-two.component";

@NgModule({
    imports: [],
    declarations: [CTwoComponent],
    exports: [CTwoComponent]
})
export class MTwoModule {

}