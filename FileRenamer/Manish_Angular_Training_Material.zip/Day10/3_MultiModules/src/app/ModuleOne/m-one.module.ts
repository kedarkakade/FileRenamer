import { NgModule } from "@angular/core";
import { COneComponent } from "./c-one.component";

@NgModule({
    imports: [],
    declarations: [COneComponent],
    exports: [COneComponent]
})
export class MOneModule {

}