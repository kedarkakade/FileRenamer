import '@angular/core';
import '@angular/common';
import '@angular/compiler';
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';

import 'rxjs';

// Import for other Vendor files, like jquery, bootstrap
import 'jquery';
import 'bootstrap';

import 'bootstrap/scss/bootstrap.scss';